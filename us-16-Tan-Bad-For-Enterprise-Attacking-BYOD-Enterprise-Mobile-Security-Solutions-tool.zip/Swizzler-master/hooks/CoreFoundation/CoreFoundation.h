/*
 File Description:
  
	*********************
	** Core Foundation **
	*********************

*/
void CFData_function_hooks();
void CFReadStream_function_hooks();
void CFSocket_function_hooks();
void CFString_function_hooks();
void CFWriteStream_function_hooks();